#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSerialPortInfo>
#include <QString>
#include <QMessageBox>
#include <QSerialPortInfo>
#include <QDateTime>
#include <QFile>
#include <QFileDialog>
#include <QDebug>
#include <QFileInfo>
#include <QtSerialPort/QSerialPort>
#include "robot.h"
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    QSerialPort *serialPort;
    QTimer *timer;
    QTimer *action_timer;
    QTimer *timersend;
    QString     SendTextStr;
    QByteArray  SendTextByte;
    quint32     dataRxNumber = 0 ;      // 记录Rx数据量
    quint8      Serial_State = 0 ;      // 串口状态
    int moveSize, angleSize;            //调节速度档位
    QPushButton *pre_move_Button,*pre_rotate_Button;
    Robot my_rov;
    void CommandSender(QString command_content, int value);           //发送指令



Q_SIGNALS:
    void data_changed();


private slots:

    void on_pushButton_move1_clicked();

    void on_pushButton_move2_clicked();

    void on_pushButton_move3_clicked();

    void on_pushButton_move4_clicked();

    void on_pushButton_move5_clicked();

    void on_pushButton_rotate1_clicked();

    void on_pushButton_rotate5_clicked();

    void on_pushButton_rotate10_clicked();
    void TimerOut();
    void serialPortReadyRead_Slot();
    void on_OpenUart_clicked();
    void on_CloseUart_clicked();
    void find_port();
    void ClearRecvButton();
    void SaveRecvDataFile();
    void on_SendDataFile_clicked();
    void TimeSendReady(int state);
    void SendDataHex(int state);
    void on_RefreshUart_clicked();

    void on_lineEdit_command_input_returnPressed();

    void AllButtonEvent_pressed();

    void AllButtonEvent_released();
private:
    Ui::MainWindow *ui;


};
#endif // MAINWINDOW_H
