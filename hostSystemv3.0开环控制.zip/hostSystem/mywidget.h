#ifndef MYWIDGET_H
#define MYWIDGET_H
#include <QtWidgets>
class MyWidget : public QWidget
{
public:
    MyWidget()
    {
        timer.setInterval(1000);
        connect(&timer, &QTimer::timeout,this,&MyWidget::onTimerTimeout);
    }
protected:
    void mousePressEvent(QMouseEvent *event) override
    {
        if(event->button() == Qt::LeftButton)
        {
            isLeftButtonPressed = true;
            timer.start();
        }
    }
    void mouseReleaseEvent(QMouseEvent *event) override
    {
        if(event->button() == Qt::LeftButton)
        {
            isLeftButtonPressed = false;
            timer.stop();
        }
    }
private slots:
    void onTimerTimeout()
    {

    }
private:
    bool isLeftButtonPressed = true;
    QTimer timer;
};

#endif // MYWIDGET_H
