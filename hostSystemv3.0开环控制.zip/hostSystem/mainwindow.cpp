#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QPushButton"
#include <QTimer>
#include <QTime>
#include <QGuiApplication>
#include <QWidget>
#include <QScreen>



QString string_button_pressed_style=R"delimiter(
                                QPushButton{color: white;padding: 16px 32px;
                                   text-align: center;
                                   text-decoration: none;
                                   font-size: 16px;
                                   margin: 4px 2px;
                                   background-color: rgb(255,255,255);
                                   color: black;
                                   border: 2px solid rgb(150,150,150);
                                   }
                                   QPushButton:hover{
                                   background-color: rgb(100,100,100);
                                   color: #000000;
                                   }

                                   QPushButton:pressed {
                                   background-color: rgb(89,89,89);
                                   })delimiter";
QString string_button_unpressed_style=R"delimiter(
                               QPushButton{color: white;padding: 16px 32px;
                                   text-align: center;
                                   text-decoration: none;
                                   font-size: 16px;
                                   margin: 4px 2px;
                                   background-color: rgb(89,89,89);
                                   color: white;
                                   border: 2px solid rgb(150,150,150);
                                   }
                                   QPushButton:hover{
                                   background-color: rgb(120,120,120);
                                   color: #000000;
                                   }

                                   QPushButton:pressed {
                                   background-color: rgb(89,89,89);
                                   })delimiter";
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    //初始化


    moveSize = 1;
    angleSize = 1;

    ui->setupUi(this);
    QScreen *screen = QGuiApplication::primaryScreen();
    QRect screenRect = screen->availableVirtualGeometry();
    resize(0.7*screenRect.width(),0.7*screenRect.height());


    //确保速度1在未点击时是亮的
    ui->pushButton_move1->setStyleSheet(string_button_pressed_style);
    ui->pushButton_rotate1->setStyleSheet(string_button_pressed_style);
    pre_move_Button = ui->pushButton_move1;
    pre_rotate_Button = ui->pushButton_rotate1;


    //串口相关
    QStringList serialNamePort;

    serialPort = new QSerialPort(this);

    //新建一个QTimer对象
    timer = new QTimer();
    action_timer = new QTimer();
    action_timer->setInterval(1000);
    //信号和槽
    connect(timer, SIGNAL(timeout()), this, SLOT(TimerOut()));


    /*定时发送定时器*/
    timersend = new QTimer();

    //定时器超时信号槽/
    connect(timersend, SIGNAL(timeout()), this, SLOT(on_SendDataFile_clicked()));

    connect(ui->timesendcheckBox,SIGNAL(stateChanged(int)),this,SLOT(TimeSendReady(int)));
    // 绑定HEX发送chexkBox信号与对应的槽函数
    connect(ui->HexsendcheckBox,SIGNAL(stateChanged(int)),this,SLOT(SendDataHex(int)));

    foreach(const QSerialPortInfo &info , QSerialPortInfo::availablePorts()){
        serialNamePort<<info.portName();
    }
    QFont font("Microsoft YaHei",10,QFont::Normal);//微软雅黑。字体大小16，Normal：正常，Bold 粗体，Black：黑体，Light：高亮
    setWindowTitle("  水下机器人调试台V3.0 ");
    ui->uartbox->addItems(serialNamePort);      // 引入当前串口
    ui->CloseUart->setEnabled(false);       // 断开按键关使能
    ui->RecvTextEdit->setFont(font);
    ui->SendTextEdit->setFont(font);

    connect(ui->ClearRecvButton, SIGNAL(clicked()), this, SLOT(ClearRecvButton()));         // 清空接收按钮
    connect(ui->SaveRecvDataFile, SIGNAL(clicked()), this, SLOT(SaveRecvDataFile()));       // 保存数据按钮

    connect(ui->pushButton_servoRight,&QPushButton::pressed, this, &MainWindow::AllButtonEvent_pressed);
    connect(ui->pushButton_servoLeft,&QPushButton::pressed, this, &MainWindow::AllButtonEvent_pressed);
    connect(ui->pushButton_servoUp,&QPushButton::pressed, this, &MainWindow::AllButtonEvent_pressed);
    connect(ui->pushButton_servoDown,&QPushButton::pressed, this, &MainWindow::AllButtonEvent_pressed);
    connect(ui->pushButton_upward,&QPushButton::pressed, this, &MainWindow::AllButtonEvent_pressed);
    connect(ui->pushButton_downward,&QPushButton::pressed, this, &MainWindow::AllButtonEvent_pressed);
    connect(ui->pushButton_roll_left,&QPushButton::pressed, this, &MainWindow::AllButtonEvent_pressed);
    connect(ui->pushButton_roll_right,&QPushButton::pressed, this, &MainWindow::AllButtonEvent_pressed);

    connect(ui->pushButton_servoRight,&QPushButton::released, this, &MainWindow::AllButtonEvent_released);
    connect(ui->pushButton_servoLeft,&QPushButton::released, this, &MainWindow::AllButtonEvent_released);
    connect(ui->pushButton_servoUp,&QPushButton::released, this, &MainWindow::AllButtonEvent_released);
    connect(ui->pushButton_servoDown,&QPushButton::released, this, &MainWindow::AllButtonEvent_released);
    connect(ui->pushButton_upward,&QPushButton::released, this, &MainWindow::AllButtonEvent_released);
    connect(ui->pushButton_downward,&QPushButton::released, this, &MainWindow::AllButtonEvent_released);
    connect(ui->pushButton_roll_left,&QPushButton::released, this, &MainWindow::AllButtonEvent_released);
    connect(ui->pushButton_roll_right,&QPushButton::released, this, &MainWindow::AllButtonEvent_released);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::TimerOut()
{
    QString     stringdata;
    timer->stop();              //关闭定时器
    ui->RecvTextEdit->setTextColor(QColor(Qt::black));
    // 读取串口接收的数据
    QByteArray  RecvBuff = serialPort->readAll() + '\n';
    if(ui->recvcheckBox->isChecked())
    {
        stringdata = RecvBuff.toHex(' ').trimmed().toUpper();/*hex显示*/
    }
    else
    {
       stringdata = QString(RecvBuff);   /*ascii显示*/
    }

    /*时间戳按钮*/
    if (ui->timecheckBox->isChecked())
    {
       stringdata = QString("[%1]:RX -> %2").arg(QTime::currentTime().toString("HH:mm:ss:zzz")).arg(stringdata);
       ui->RecvTextEdit->append(stringdata);
    }
    else
    {
        ui->RecvTextEdit->insertPlainText(stringdata);
    }
    ui->RecvTextEdit->moveCursor(QTextCursor::End);  // 自动滚屏到最后一行 有BUG 不可用光标点击文本框
    dataRxNumber += RecvBuff.length();
    ui->RxNumlabel->setText(QString::number(dataRxNumber));
    RecvBuff.clear();
}
void MainWindow::serialPortReadyRead_Slot()
{
    //启动定时器
    timer->start(10);
}

/*函   数：on_OpenUart_clicked
描   述：打开并设置串口的信号槽函数
输   入：无
输   出：无
*/
void MainWindow::on_OpenUart_clicked()
{

    serialPort->setPortName(ui->uartbox->currentText());
    serialPort->setBaudRate(ui->baudbox->currentText().toInt());            //设置波特率
    serialPort->setDataBits(QSerialPort::Data8);                            //设置数据位数  默认8位
    serialPort->setParity(QSerialPort::NoParity);                           //设置奇偶校验  默认无奇偶
    serialPort->setStopBits(QSerialPort::OneStop);                          //设置停止位    默认无停止
    serialPort->setFlowControl(QSerialPort::NoFlowControl);                 //设置流控制    默认无

    connect(serialPort,SIGNAL(readyRead()),this,SLOT(serialPortReadyRead_Slot()));

    if(serialPort->open(QIODevice::ReadWrite))              //打开串口成功
    {
        ui->OpenUart->setEnabled(false);
        ui->CloseUart->setEnabled(true);
        Serial_State = true;
        QMessageBox::warning(this,tr("提示"),tr("串口连接成功"));
    }
    else
    {
        QMessageBox::warning(this,tr("错误"),tr("串口连接失败"));
    }

}


void MainWindow::on_CloseUart_clicked()
{
    serialPort->close();
    Serial_State = 0;
    ui->OpenUart->setEnabled(true);     // 连接串口按键使能
    ui->CloseUart->setEnabled(false);   // 断开按键关使能
}
/*
    函   数：find_port
    描   述：查找串口
    输   入：无
    输   出：无
*/
void MainWindow::find_port()
{
    ui->uartbox->clear();
    foreach(const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
    {
        QSerialPort serial;
        serial.setPort(info);   //设置串口
        if(serial.open(QIODevice::ReadWrite))
        {
            ui->uartbox->addItem(serial.portName());        //显示串口名称
            serial.close();
        }
    }
}

void MainWindow::ClearRecvButton()
{
    ui->RecvTextEdit->clear();
    dataRxNumber = 0 ;
    ui->RxNumlabel->setText(QString::number(dataRxNumber));
}
/*
    函   数：SaveRecvDataFile
    描   述：保存数据按钮点击槽函数
    输   入：无
    输   出：无
*/
void MainWindow::SaveRecvDataFile()
{
    QString data;

    data = ui->RecvTextEdit->toPlainText();

    if (data.isEmpty())
    {
        QMessageBox::information(this, "提示", "数据内容空");
        return;
    }
    QString curPath = QDir::currentPath();            //获取系统当前目录
    QString dlgTitle = "保存文件";                     //对话框标题
    QString filter = "文本文件(*.txt);;所有文件(*.*)";  //文件过滤器
    QString filename = QFileDialog::getSaveFileName(this,dlgTitle,curPath,filter);
    if (filename.isEmpty())
    {
        return;
    }
    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly))
    {
        return;
    }
    /*保存文件*/
    QTextStream stream(&file);
    stream << data;
    file.close();
}

/*
    函   数：on_SendDataFile_clicked
    描   述：手动发送数据
    输   入：无
    输   出：无
*/
void MainWindow::on_SendDataFile_clicked()
{

    if (bool(Serial_State) == true)
    {
        //获取发送框字符
        SendTextStr = ui->SendTextEdit->document()->toPlainText();
        SendTextByte = SendTextStr.toUtf8();
        if (SendTextByte.isEmpty() != true)
        {

            if (ui->HexsendcheckBox->isChecked())
            {
                SendTextByte = SendTextByte.fromHex(SendTextByte);
                serialPort->write(SendTextByte); // 发送hex数据
                QString strdata = SendTextByte.toHex(' ').trimmed().toUpper();
                if (ui->timecheckBox->isChecked()) // 时间戳发送
                {
                    ui->RecvTextEdit->setTextColor(QColor(Qt::blue));  // 时间戳颜色
                    ui->RecvTextEdit->append(QString("[%1]TX -> ").arg(QTime::currentTime().toString("HH:mm:ss:zzz")));
                }
                else
                {
                  strdata = strdata.append("\r\n");
                }
                ui->RecvTextEdit->setTextColor(QColor(Qt::black));
                ui->RecvTextEdit->insertPlainText(strdata);
            }
            else
            {
                // 发送ascii数据
                serialPort->write(SendTextByte);
                QString strdata = QString(SendTextByte);
                if (ui->timecheckBox->isChecked()) // 时间戳发送
                {
                    ui->RecvTextEdit->setTextColor(QColor(Qt::red)); // 时间戳颜色
                    ui->RecvTextEdit->append(QString("[%1]TX -> ").arg(QTime::currentTime().toString("HH:mm:ss:zzz")));
                }
                else
                {
                   strdata = strdata.append("\r\n");
                }
                ui->RecvTextEdit->setTextColor(QColor(Qt::black));
                ui->RecvTextEdit->insertPlainText(strdata);
            }
            //移动光标到末尾
            ui->RecvTextEdit->moveCursor(QTextCursor::End);
        }
        else
        {
            QMessageBox::warning(this, "警告", "您需要在发送编辑框中输入要发送的数据");
        }

    }
    else
    {
        QMessageBox::information(this, "警告", "串口未打开");
    }
}
/*
    函   数：TimeSendReady
    描   述：定时发送信号槽函数
    输   入：无
    输   出：无
*/
void MainWindow::TimeSendReady(int state)
{
    int settime;

    if (bool(Serial_State) == false)
    {
        QMessageBox::information(this, "提示", "串口未打开");
        return;
    }
    /*判断是否有数据*/
    if (ui->SendTextEdit->document()->isEmpty() == true)
    {
        if (ui->timesendcheckBox->isChecked())
        {
            QMessageBox::warning(this, "警告", "您需要在发送编辑框中输入要发送的数据");
        }
        return;
    }
    /*判断勾选状态*/
    if (state == Qt::Checked)
    {
        /*获取设定时间*/
        settime = ui->timelineEdit->text().toInt();
        if (settime > 0) {
            timersend->start(settime);
        } else {
            QMessageBox::warning(this, "警告", "时间必须大于0");
        }
        ui->timelineEdit->setEnabled(false);
    }
    else
    {
        /*停止发送*/
        timersend->stop();
        ui->timelineEdit->setEnabled(true);
    }
}
void MainWindow::SendDataHex(int state)
{
    //获取发送框字符
    SendTextStr = ui->SendTextEdit->document()->toPlainText();
    SendTextByte = SendTextStr.toUtf8();
    if (SendTextStr.isEmpty())
    {
        return;
    }
    //asccii与hex转换
    if (state == Qt::Checked)
    {
        //转换成16进制数并转换为大写
        SendTextByte = SendTextByte.toHex(' ').toUpper();
        ui->SendTextEdit->document()->setPlainText(SendTextByte);
    }
    else
    {
        //从QByteArray转换为QString
        SendTextStr = SendTextByte.fromHex(SendTextByte);
        ui->SendTextEdit->document()->setPlainText(SendTextStr);
    }
}

void MainWindow::on_RefreshUart_clicked()
{
    ui->uartbox->clear();
    foreach(const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
    {
        QSerialPort serial;
        serial.setPort(info);   //设置串口
        if(serial.open(QIODevice::ReadWrite))
        {
            ui->uartbox->addItem(serial.portName());        //显示串口名称
            serial.close();
        }
    }
}



void MainWindow::on_pushButton_move1_clicked()
{
    moveSize = 1;
    if (pre_move_Button != ui->pushButton_move1)
    {

        ui->pushButton_move1->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_move1;
    }
}


void MainWindow::on_pushButton_move2_clicked()
{
    moveSize = 2;
    if (pre_move_Button != ui->pushButton_move2)
    {
        ui->pushButton_move2->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_move2;
    }
}


void MainWindow::on_pushButton_move3_clicked()
{
    moveSize = 3;
    if (pre_move_Button != ui->pushButton_move3){
        ui->pushButton_move3->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_move3;
    }
}


void MainWindow::on_pushButton_move4_clicked()
{
    moveSize = 4;
    if (pre_move_Button != ui->pushButton_move4){
        ui->pushButton_move4->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_move4;
    }
}


void MainWindow::on_pushButton_move5_clicked()
{
    moveSize = 5;
    if (pre_move_Button != ui->pushButton_move5){
        ui->pushButton_move5->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_move5;
    }
}


void MainWindow::on_pushButton_rotate1_clicked()
{
    angleSize = 1;
    if (pre_rotate_Button != ui->pushButton_rotate1){
        ui->pushButton_rotate1->setStyleSheet(string_button_pressed_style);
        pre_rotate_Button->setStyleSheet(string_button_unpressed_style);
        pre_rotate_Button = ui->pushButton_rotate1;
    }
}


void MainWindow::on_pushButton_rotate5_clicked()
{
    angleSize = 5;
    if (pre_rotate_Button != ui->pushButton_rotate5){
        ui->pushButton_rotate5->setStyleSheet(string_button_pressed_style);
        pre_rotate_Button->setStyleSheet(string_button_unpressed_style);
        pre_rotate_Button = ui->pushButton_rotate5;
    }
}


void MainWindow::on_pushButton_rotate10_clicked()
{
    angleSize = 10;
    if (pre_rotate_Button != ui->pushButton_rotate10){
        ui->pushButton_rotate10->setStyleSheet(string_button_pressed_style);
        pre_rotate_Button->setStyleSheet(string_button_unpressed_style);
        pre_rotate_Button = ui->pushButton_rotate10;
    }
}

void MainWindow::CommandSender(QString commander_content, int value)
{

    if (bool(Serial_State) == true)
    {
        //获取发送框字符
        SendTextStr = commander_content + QString::number(value) + '\n';

        //要将QString转变为char*才能实现发送字符串
        std::string String_TextStr = SendTextStr.toStdString();
        const char* StringSend = String_TextStr.c_str();
        SendTextByte = SendTextStr.toUtf8();
        //StringSend为真正要发的数据
        if (String_TextStr.empty() != true && (String_TextStr[0] == 'T' || String_TextStr[0] == 'G' || String_TextStr[0] == 'R' || String_TextStr[0] == 'P'))
        {
            ui->SendTextEdit->append(QString("%1%2").arg(commander_content).arg(QString::number(value)));

            // 发送ascii数据
            serialPort->write(StringSend);
            QString strdata = QString(SendTextByte);

        }
        else if(String_TextStr.empty() == true)
        {
            QMessageBox::information(this,"警告","命令不能为空");
        }
        else
        {
            QMessageBox::information(this,"警告","不能识别的命令，请检查命令后重试");
        }
    }
    else
    {
        QMessageBox::information(this, "警告", "串口未打开");
    }


}




//命令栏按下回车后执行，需要读取命令并重新输入到commandSender里来保证正确的格式
void MainWindow::on_lineEdit_command_input_returnPressed()
{

    SendTextStr = ui->lineEdit_command_input->text();
    if (SendTextStr[0] == 'T')
    {
        CommandSender(SendTextStr,angleSize);

    }
    else
    {
        CommandSender(SendTextStr, moveSize);

    }

}


//运动相关的按钮按下后就执行的槽函数
void MainWindow::AllButtonEvent_pressed()
{
    QPushButton *button = qobject_cast<QPushButton *>(sender());
    if (button == ui->pushButton_servoRight)
    {
        CommandSender("TR", angleSize);         //servo turn right
    }
    else if (button == ui->pushButton_servoLeft)
    {
        CommandSender("TL", angleSize);         //servo turn left
    }
    else if (button == ui->pushButton_servoUp)
    {
        CommandSender("TU", angleSize);         //servo turn up
    }
    else if (button == ui->pushButton_servoDown)
    {
        CommandSender("TD", angleSize);         //servo turn down
    }
    else if (button == ui->pushButton_roll_left)
    {
        CommandSender("RL",moveSize);           //ROV roll left
    }
    else if (button == ui->pushButton_roll_right)
    {
        CommandSender("RR",moveSize);           //ROV roll right
    }
    else if (button == ui->pushButton_backward)
    {
        CommandSender("GB",moveSize);           //ROV go backward
    }
    else if (button == ui->pushButton_forward)
    {
        CommandSender("GF",moveSize);           //ROV go forward
    }
    else if (button == ui->pushButton_upward)
    {
        CommandSender("GU",moveSize);           //ROV go upward
    }
    else if (button == ui->pushButton_downward)
    {
        CommandSender("GD",moveSize);           //ROV go downward
    }


}

void MainWindow::AllButtonEvent_released()
{
    CommandSender("PA",1);                        //ROV Pause
}
