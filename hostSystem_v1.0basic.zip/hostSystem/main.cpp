#include "mainwindow.h"

#include <QApplication>
#include <QPushButton>
int moveSize=1,angleSize=1;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
