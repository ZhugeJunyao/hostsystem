#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QPushButton"
extern int moveSize,angleSize;
QPushButton *pre_move_Button,*pre_rotate_Button;
QString string_button_pressed_style=R"delimiter(
                                QPushButton{color: white;padding: 16px 32px;
                                   text-align: center;
                                   text-decoration: none;
                                   font-size: 16px;
                                   margin: 4px 2px;
                                   background-color: rgb(255,255,255);
                                   color: black;
                                   border: 2px solid rgb(150,150,150);
                                   }
                                   QPushButton:hover{
                                   background-color: rgb(100,100,100);
                                   color: #000000;
                                   }

                                   QPushButton:pressed {
                                   background-color: rgb(89,89,89);
                                   })delimiter";
QString string_button_unpressed_style=R"delimiter(
                               QPushButton{color: white;padding: 16px 32px;
                                   text-align: center;
                                   text-decoration: none;
                                   font-size: 16px;
                                   margin: 4px 2px;
                                   background-color: rgb(89,89,89);
                                   color: white;
                                   border: 2px solid rgb(150,150,150);
                                   }
                                   QPushButton:hover{
                                   background-color: rgb(120,120,120);
                                   color: #000000;
                                   }

                                   QPushButton:pressed {
                                   background-color: rgb(89,89,89);
                                   })delimiter";
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->label_right_title->setVisible(false);
    ui->pushButton_backward->setVisible(false);
    ui->pushButton_downward->setVisible(false);
    ui->pushButton_leftward->setVisible(false);
    ui->pushButton_rightward->setVisible(false);
    ui->pushButton_toward->setVisible(false);
    ui->pushButton_upward->setVisible(false);
    ui->label_xy->setVisible(false);
    ui->label_z->setVisible(false);
    ui->pushButton_move1->setVisible(false);
    ui->pushButton_move10->setVisible(false);
    ui->pushButton_move25->setVisible(false);
    ui->pushButton_move50->setVisible(false);
    ui->pushButton_move100->setVisible(false);
    ui->label_word_velocity_choose->setVisible(false);
    ui->label_word_x->setVisible(false);ui->label_data_x->setVisible(false);
    ui->label_word_y->setVisible(false);ui->label_data_y->setVisible(false);
    ui->label_word_z->setVisible(false);ui->label_data_z->setVisible(false);
    ui->label_word_pitch->setVisible(false);
    ui->label_word_roll->setVisible(false);
    ui->label_word_yaw->setVisible(false);
    ui->label_data_pitch->setVisible(false);
    ui->label_data_roll->setVisible(false);
    ui->label_data_yaw->setVisible(false);
    ui->pushButton_roll_left->setVisible(false);ui->pushButton_roll_right->setVisible(false);
    ui->pushButton_pitch_left->setVisible(false);ui->pushButton_pitch_right->setVisible(false);
    ui->pushButton_yaw_left->setVisible(false);ui->pushButton_yaw_right->setVisible(false);
    ui->pushButton_rotate1->setVisible(false);ui->pushButton_rotate5->setVisible(false);ui->pushButton_rotate10->setVisible(false);

}

MainWindow::~MainWindow()
{
    delete ui;
}
void chosen_Button(){
}

void MainWindow::on_pushButton_connect_clicked()
{
    bool connect_flag=false;
    if (true){           //TODO:判断是否连接成功
        delete ui->label_IP;
        delete ui->lineEdit_IP;
        delete ui->pushButton_connect;
        connect_flag=true;
    }
    else{
        QLabel *label_error= new QLabel(this);
        label_error->setText("连接失败，请稍后重试");
        label_error->setGeometry(370,450,150,50);
        label_error->show();
    }
    while (connect_flag==false){}
    ui->label_right_title->setVisible(true);
    ui->pushButton_backward->setVisible(true);
    ui->pushButton_downward->setVisible(true);
    ui->pushButton_leftward->setVisible(true);
    ui->pushButton_rightward->setVisible(true);
    ui->pushButton_toward->setVisible(true);
    ui->pushButton_upward->setVisible(true);
    ui->label_xy->setVisible(true);
    ui->label_z->setVisible(true);
    ui->pushButton_move1->setVisible(true);
    ui->pushButton_move10->setVisible(true);
    ui->pushButton_move25->setVisible(true);
    ui->pushButton_move50->setVisible(true);
    ui->pushButton_move100->setVisible(true);
    ui->label_word_velocity_choose->setVisible(true);
    ui->label_word_x->setVisible(true);ui->label_data_x->setVisible(true);
    ui->label_word_y->setVisible(true);ui->label_data_y->setVisible(true);
    ui->label_word_z->setVisible(true);ui->label_data_z->setVisible(true);
    ui->label_word_pitch->setVisible(true);
    ui->label_word_roll->setVisible(true);
    ui->label_word_yaw->setVisible(true);
    ui->label_data_pitch->setVisible(true);
    ui->label_data_roll->setVisible(true);
    ui->label_data_yaw->setVisible(true);
    ui->pushButton_roll_left->setVisible(true);ui->pushButton_roll_right->setVisible(true);
    ui->pushButton_pitch_left->setVisible(true);ui->pushButton_pitch_right->setVisible(true);
    ui->pushButton_yaw_left->setVisible(true);ui->pushButton_yaw_right->setVisible(true);
    ui->pushButton_rotate1->setVisible(true);ui->pushButton_rotate5->setVisible(true);ui->pushButton_rotate10->setVisible(true);
    ui->label_background->lower();
    pre_move_Button = ui->pushButton_move1;
    pre_rotate_Button = ui->pushButton_rotate1;

}


void MainWindow::on_pushButton_yaw_left_clicked()
{
    int yaw_cur=ui->label_data_yaw->text().toInt();
    yaw_cur =yaw_cur-angleSize;
    ui->label_data_yaw->setText(QString::number(yaw_cur));
}


void MainWindow::on_pushButton_yaw_right_clicked()
{
    int yaw_cur=ui->label_data_yaw->text().toInt();
    yaw_cur =yaw_cur+angleSize;
    ui->label_data_yaw->setText(QString::number(yaw_cur));
}


void MainWindow::on_pushButton_roll_left_clicked()
{
    int roll_cur=ui->label_data_roll->text().toInt();
    roll_cur =roll_cur-angleSize;
    ui->label_data_roll->setText(QString::number(roll_cur));
}


void MainWindow::on_pushButton_roll_right_clicked()
{
    int roll_cur=ui->label_data_roll->text().toInt();
    roll_cur =roll_cur+angleSize;
    ui->label_data_roll->setText(QString::number(roll_cur));
}


void MainWindow::on_pushButton_pitch_left_clicked()
{
    int pitch_cur=ui->label_data_pitch->text().toInt();
    pitch_cur =pitch_cur-angleSize;
    ui->label_data_pitch->setText(QString::number(pitch_cur));
}


void MainWindow::on_pushButton_pitch_right_clicked()
{
    int pitch_cur=ui->label_data_pitch->text().toInt();
    pitch_cur =pitch_cur+angleSize;
    ui->label_data_pitch->setText(QString::number(pitch_cur));
}


void MainWindow::on_pushButton_toward_clicked()
{
    int y_cur=ui->label_data_y->text().toInt();
    y_cur =y_cur+moveSize;
    ui->label_data_y->setText(QString::number(y_cur));
}


void MainWindow::on_pushButton_backward_clicked()
{
    int y_cur=ui->label_data_y->text().toInt();
    y_cur =y_cur-moveSize;
    ui->label_data_y->setText(QString::number(y_cur));
}


void MainWindow::on_pushButton_leftward_clicked()
{
    int x_cur=ui->label_data_x->text().toInt();
    x_cur =x_cur-moveSize;
    ui->label_data_x->setText(QString::number(x_cur));
}


void MainWindow::on_pushButton_rightward_clicked()
{
    int x_cur=ui->label_data_x->text().toInt();
    x_cur =x_cur+moveSize;
    ui->label_data_x->setText(QString::number(x_cur));
}


void MainWindow::on_pushButton_upward_clicked()
{
    int z_cur=ui->label_data_z->text().toInt();
    z_cur =z_cur+moveSize;
    ui->label_data_z->setText(QString::number(z_cur));
}


void MainWindow::on_pushButton_downward_clicked()
{
    int z_cur=ui->label_data_z->text().toInt();
    z_cur =z_cur-moveSize;
    ui->label_data_z->setText(QString::number(z_cur));
}


void MainWindow::on_pushButton_move1_clicked()
{
    moveSize = 1;
    if (pre_move_Button != ui->pushButton_move1){
        ui->pushButton_move1->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_move1;
    }
}


void MainWindow::on_pushButton_move10_clicked()
{
    moveSize=10;
    if (pre_move_Button != ui->pushButton_move10){
        ui->pushButton_move10->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_move10;
    }
}


void MainWindow::on_pushButton_move25_clicked()
{
    moveSize=25;
    if (pre_move_Button != ui->pushButton_move25){
        ui->pushButton_move25->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_move25;
    }
}


void MainWindow::on_pushButton_move50_clicked()
{
    moveSize=50;
    if (pre_move_Button != ui->pushButton_move50){
        ui->pushButton_move50->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_move50;
    }
}


void MainWindow::on_pushButton_move100_clicked()
{
    moveSize=100;
    if (pre_move_Button != ui->pushButton_move100){
        ui->pushButton_move100->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_move100;
    }
}


void MainWindow::on_pushButton_rotate1_clicked()
{
    angleSize = 1;
    if (pre_rotate_Button != ui->pushButton_rotate1){
        ui->pushButton_rotate1->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_rotate1;
    }
}


void MainWindow::on_pushButton_rotate5_clicked()
{
    angleSize = 5;
    if (pre_rotate_Button != ui->pushButton_rotate5){
        ui->pushButton_rotate5->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_rotate5;
    }
}


void MainWindow::on_pushButton_rotate10_clicked()
{
    angleSize = 10;
    if (pre_rotate_Button != ui->pushButton_rotate10){
        ui->pushButton_rotate10->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_rotate10;
    }
}


