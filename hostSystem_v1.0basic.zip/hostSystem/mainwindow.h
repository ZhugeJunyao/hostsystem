#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
private slots:
    void on_pushButton_connect_clicked();

    void on_pushButton_yaw_left_clicked();

    void on_pushButton_yaw_right_clicked();

    void on_pushButton_roll_left_clicked();

    void on_pushButton_roll_right_clicked();

    void on_pushButton_pitch_left_clicked();

    void on_pushButton_pitch_right_clicked();

    void on_pushButton_toward_clicked();

    void on_pushButton_backward_clicked();

    void on_pushButton_leftward_clicked();

    void on_pushButton_rightward_clicked();

    void on_pushButton_upward_clicked();

    void on_pushButton_downward_clicked();

    void on_pushButton_move1_clicked();

    void on_pushButton_move10_clicked();

    void on_pushButton_move25_clicked();

    void on_pushButton_move50_clicked();

    void on_pushButton_move100_clicked();

    void on_pushButton_rotate1_clicked();

    void on_pushButton_rotate5_clicked();

    void on_pushButton_rotate10_clicked();



private:
    Ui::MainWindow *ui;

};
#endif // MAINWINDOW_H
