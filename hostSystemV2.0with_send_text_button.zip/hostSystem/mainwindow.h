#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSerialPortInfo>
#include <QString>
#include <QMessageBox>
#include <QSerialPortInfo>
#include <QDateTime>
#include <QFile>
#include <QFileDialog>
#include <QDebug>
#include <QFileInfo>
#include <QtSerialPort/QSerialPort>
#include "robot.h"
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    QSerialPort *serialPort;
    QTimer *timer;
    QTimer *timersend;
    QString     SendTextStr;
    QByteArray  SendTextByte;
    quint32     dataRxNumber = 0 ;      // 记录Rx数据量
    quint8      Serial_State = 0 ;      // 串口状态
    Robot my_rov;
    void if_position_changed();             //判断是否位姿（位置和姿势）发生改变，如果发生改变，发送指令
    void CommandSender(QString command_content, float value);           //发送指令，可能要重载
    void CommandSender(QString whole_command);
    void HideAll();                         //隐藏第二界面的控件
    void ShowAll();                       //显示被隐藏的控件

Q_SIGNALS:
    void data_changed();
private slots:
    void on_pushButton_connect_clicked();

    void on_pushButton_yaw_left_clicked();

    void on_pushButton_yaw_right_clicked();

    void on_pushButton_roll_left_clicked();

    void on_pushButton_roll_right_clicked();

    void on_pushButton_pitch_left_clicked();

    void on_pushButton_pitch_right_clicked();

    void on_pushButton_toward_clicked();

    void on_pushButton_backward_clicked();

    void on_pushButton_leftward_clicked();

    void on_pushButton_rightward_clicked();

    void on_pushButton_upward_clicked();

    void on_pushButton_downward_clicked();

    void on_pushButton_move1_clicked();

    void on_pushButton_move10_clicked();

    void on_pushButton_move25_clicked();

    void on_pushButton_move50_clicked();

    void on_pushButton_move100_clicked();

    void on_pushButton_rotate1_clicked();

    void on_pushButton_rotate5_clicked();

    void on_pushButton_rotate10_clicked();
    void TimerOut();
    void serialPortReadyRead_Slot();
    void on_OpenUart_clicked();
    void on_CloseUart_clicked();
    void find_port();
    void ClearRecvButton();
    void SaveRecvDataFile();
    void on_SendDataFile_clicked();
    void TimeSendReady(int state);
    void SendDataHex(int state);
    void on_RefreshUart_clicked();

    void on_lineEdit_command_input_returnPressed();

private:
    Ui::MainWindow *ui;
    float m_Position_x, m_Position_y, m_Position_z;
    float m_Angle_Roll, m_Angle_Pitch, m_Angle_Yaw;
    float m_pre_Position_x, m_pre_Position_y, m_pre_Position_z;
    float m_pre_Angle_Roll, m_pre_Angle_Pitch, m_pre_Angle_Yaw;
    int moveSize, angleSize;

};
#endif // MAINWINDOW_H
