#ifndef ROBOT_H
#define ROBOT_H
#include <vector>
#include <string>
class Robot
{
public:
    Robot();
    void SetPosition(float x, float y, float z);
    void SetPosition();
    void SetAngle(float theta_Y, float theta_R, float theta_P);
    std::vector<float> GetPosition();
    float GetPositionX();
    float GetPositionY();
    float GetPositionZ();
    float GetAngleY();
    float GetAngleR();
    float GetAngleP();
    std::vector<float> GetAngle();
    void CommandSender(char command);
    void CommandReceiver();


private:
    float m_real_x, m_real_y, m_real_z;
    float m_real_pre_x, m_real_pre_y, m_real_pre_z;
    float m_real_theta_Y, m_real_theta_R, m_real_theta_P;

};

#endif // ROBOT_H
