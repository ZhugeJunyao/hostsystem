#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QPushButton"
#include <QTimer>
#include <QTime>
#include <QGuiApplication>
#include <QWidget>
#include <QScreen>
extern int moveSize,angleSize;
QPushButton *pre_move_Button,*pre_rotate_Button;

QString string_button_pressed_style=R"delimiter(
                                QPushButton{color: white;padding: 16px 32px;
                                   text-align: center;
                                   text-decoration: none;
                                   font-size: 16px;
                                   margin: 4px 2px;
                                   background-color: rgb(255,255,255);
                                   color: black;
                                   border: 2px solid rgb(150,150,150);
                                   }
                                   QPushButton:hover{
                                   background-color: rgb(100,100,100);
                                   color: #000000;
                                   }

                                   QPushButton:pressed {
                                   background-color: rgb(89,89,89);
                                   })delimiter";
QString string_button_unpressed_style=R"delimiter(
                               QPushButton{color: white;padding: 16px 32px;
                                   text-align: center;
                                   text-decoration: none;
                                   font-size: 16px;
                                   margin: 4px 2px;
                                   background-color: rgb(89,89,89);
                                   color: white;
                                   border: 2px solid rgb(150,150,150);
                                   }
                                   QPushButton:hover{
                                   background-color: rgb(120,120,120);
                                   color: #000000;
                                   }

                                   QPushButton:pressed {
                                   background-color: rgb(89,89,89);
                                   })delimiter";
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    //初始化
    m_Position_x = 0;
    m_Position_y = 0;
    m_Position_z = 0;

    m_Angle_Roll = 0;
    m_Angle_Pitch = 0;
    m_Angle_Yaw = 0;
    moveSize = 1;
    angleSize = 1;

    m_pre_Position_x = 0;
    m_pre_Position_y = 0;
    m_pre_Position_z = 0;
    m_pre_Angle_Pitch = 0;
    m_pre_Angle_Roll = 0;
    m_pre_Angle_Yaw = 0;

    ui->setupUi(this);
    QScreen *screen = QGuiApplication::primaryScreen();
    QRect screenRect = screen->availableVirtualGeometry();
    resize(0.7*screenRect.width(),0.7*screenRect.height());

    HideAll();


    //确保速度1在未点击时是亮的
    ui->pushButton_move1->setStyleSheet(string_button_pressed_style);
    ui->pushButton_rotate1->setStyleSheet(string_button_pressed_style);
    //串口相关
    QStringList serialNamePort;

    serialPort = new QSerialPort(this);

    //新建一个QTimer对象
    timer = new QTimer();


    //信号和槽
    connect(timer, SIGNAL(timeout()), this, SLOT(TimerOut()));

    /*定时发送定时器*/
    timersend = new QTimer();
    //定时器超时信号槽/
    connect(timersend, SIGNAL(timeout()), this, SLOT(on_SendDataFile_clicked()));

    connect(ui->timesendcheckBox,SIGNAL(stateChanged(int)),this,SLOT(TimeSendReady(int)));
    // 绑定HEX发送chexkBox信号与对应的槽函数
    connect(ui->HexsendcheckBox,SIGNAL(stateChanged(int)),this,SLOT(SendDataHex(int)));

    foreach(const QSerialPortInfo &info , QSerialPortInfo::availablePorts()){
        serialNamePort<<info.portName();
    }
    QFont font("Microsoft YaHei",10,QFont::Normal);//微软雅黑。字体大小16，Normal：正常，Bold 粗体，Black：黑体，Light：高亮
    setWindowTitle("  串口助手 V1.0 ");
    ui->uartbox->addItems(serialNamePort);      // 引入当前串口
    ui->CloseUart->setEnabled(false);       // 断开按键关使能
    ui->RecvTextEdit->setFont(font);
    ui->SendTextEdit->setFont(font);
    connect(ui->ClearRecvButton, SIGNAL(clicked()), this, SLOT(ClearRecvButton()));         // 清空接收按钮
    connect(ui->SaveRecvDataFile, SIGNAL(clicked()), this, SLOT(SaveRecvDataFile()));       // 保存数据按钮
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::HideAll()
{
    ui->label_right_title->setVisible(false);
    ui->pushButton_backward->setVisible(false);
    ui->pushButton_downward->setVisible(false);
    ui->pushButton_leftward->setVisible(false);
    ui->pushButton_rightward->setVisible(false);
    ui->pushButton_toward->setVisible(false);
    ui->pushButton_upward->setVisible(false);
    ui->label_xy->setVisible(false);
    ui->label_z->setVisible(false);
    ui->pushButton_move1->setVisible(false);
    ui->pushButton_move10->setVisible(false);
    ui->pushButton_move25->setVisible(false);
    ui->pushButton_move50->setVisible(false);
    ui->pushButton_move100->setVisible(false);
    ui->label_word_velocity_choose->setVisible(false);
    ui->label_word_rotation_choose->setVisible(false);
    ui->label_word_x->setVisible(false);ui->label_data_x->setVisible(false);
    ui->label_word_y->setVisible(false);ui->label_data_y->setVisible(false);
    ui->label_word_z->setVisible(false);ui->label_data_z->setVisible(false);
    ui->label_word_pitch->setVisible(false);
    ui->label_word_roll->setVisible(false);
    ui->label_word_yaw->setVisible(false);
    ui->label_data_pitch->setVisible(false);
    ui->label_data_roll->setVisible(false);
    ui->label_data_yaw->setVisible(false);
    ui->pushButton_roll_left->setVisible(false);ui->pushButton_roll_right->setVisible(false);
    ui->pushButton_pitch_left->setVisible(false);ui->pushButton_pitch_right->setVisible(false);
    ui->pushButton_yaw_left->setVisible(false);ui->pushButton_yaw_right->setVisible(false);
    ui->pushButton_rotate1->setVisible(false);ui->pushButton_rotate5->setVisible(false);ui->pushButton_rotate10->setVisible(false);

    //串口隐藏
    ui->ClearRecvButton->setVisible(false);
    ui->RecvTextEdit->setVisible(false);
    ui->SendTextEdit->setVisible(false);
    ui->HexsendcheckBox->setVisible(false);
    ui->CloseUart->setVisible(false);
    ui->OpenUart->setVisible(false);
    ui->RefreshUart->setVisible(false);
    ui->uartbox->setVisible(false);
    ui->RxNumlabel->setVisible(false);
    ui->SaveRecvDataFile->setVisible(false);
    ui->baudbox->setVisible(false);
    ui->label_serial->setVisible(false);
    ui->label_stop->setVisible(false);
    ui->label_8->setVisible(false);
    ui->label_check->setVisible(false);
    ui->label_baud->setVisible(false);
    ui->label_data->setVisible(false);
    ui->databox->setVisible(false);
    ui->HexsendcheckBox->setVisible(false);
    ui->recvcheckBox->setVisible(false);
    ui->timecheckBox->setVisible(false);
    ui->timesendcheckBox->setVisible(false);
    ui->stopbox->setVisible(false);
    ui->nonebox->setVisible(false);
    ui->SendDataFile->setVisible(false);
    ui->timelineEdit->setVisible(false);
    ui->lineEdit_command_input->setVisible(false);
}
void MainWindow::ShowAll()
{
    ui->label_right_title->setVisible(true);
    ui->pushButton_backward->setVisible(true);
    ui->pushButton_downward->setVisible(true);
    ui->pushButton_leftward->setVisible(true);
    ui->pushButton_rightward->setVisible(true);
    ui->pushButton_toward->setVisible(true);
    ui->pushButton_upward->setVisible(true);
    ui->label_xy->setVisible(true);
    ui->label_z->setVisible(true);
    ui->pushButton_move1->setVisible(true);
    ui->pushButton_move10->setVisible(true);
    ui->pushButton_move25->setVisible(true);
    ui->pushButton_move50->setVisible(true);
    ui->pushButton_move100->setVisible(true);
    ui->label_word_velocity_choose->setVisible(true);
    ui->label_word_rotation_choose->setVisible(true);
    ui->label_word_x->setVisible(true);ui->label_data_x->setVisible(true);
    ui->label_word_y->setVisible(true);ui->label_data_y->setVisible(true);
    ui->label_word_z->setVisible(true);ui->label_data_z->setVisible(true);
    ui->label_word_pitch->setVisible(true);
    ui->label_word_roll->setVisible(true);
    ui->label_word_yaw->setVisible(true);
    ui->label_data_pitch->setVisible(true);
    ui->label_data_roll->setVisible(true);
    ui->label_data_yaw->setVisible(true);
    ui->pushButton_roll_left->setVisible(true);ui->pushButton_roll_right->setVisible(true);
    ui->pushButton_pitch_left->setVisible(true);ui->pushButton_pitch_right->setVisible(true);
    ui->pushButton_yaw_left->setVisible(true);ui->pushButton_yaw_right->setVisible(true);
    ui->pushButton_rotate1->setVisible(true);ui->pushButton_rotate5->setVisible(true);ui->pushButton_rotate10->setVisible(true);
    ui->label_background->lower();

    //串口显示
    ui->ClearRecvButton->setVisible(true);
    ui->RecvTextEdit->setVisible(true);
    ui->SendTextEdit->setVisible(true);
    ui->HexsendcheckBox->setVisible(true);
    ui->CloseUart->setVisible(true);
    ui->OpenUart->setVisible(true);
    ui->RefreshUart->setVisible(true);
    ui->uartbox->setVisible(true);
    ui->RxNumlabel->setVisible(true);
    ui->SaveRecvDataFile->setVisible(true);
    ui->baudbox->setVisible(true);
    ui->label_serial->setVisible(true);
    ui->label_stop->setVisible(true);
    ui->label_8->setVisible(true);
    ui->label_check->setVisible(true);
    ui->label_baud->setVisible(true);
    ui->label_data->setVisible(true);
    ui->databox->setVisible(true);
    ui->HexsendcheckBox->setVisible(true);
    ui->recvcheckBox->setVisible(true);
    ui->timecheckBox->setVisible(true);
    ui->timesendcheckBox->setVisible(true);
    ui->stopbox->setVisible(true);
    ui->nonebox->setVisible(true);
    ui->SendDataFile->setVisible(true);
    ui->timelineEdit->setVisible(true);
    ui->lineEdit_command_input->setVisible(true);
}
void MainWindow::on_pushButton_connect_clicked()
{
    bool connect_flag=false;
    if (true){           //TODO:判断是否连接成功
        delete ui->label_IP;
        delete ui->lineEdit_IP;
        delete ui->pushButton_connect;
        connect_flag=true;
    }
    else{
        QLabel *label_error= new QLabel(this);
        label_error->setText("连接失败，请稍后重试");
        label_error->setGeometry(370,450,150,50);
        label_error->show();
    }
    while (connect_flag==false){}

    ShowAll();
    pre_move_Button = ui->pushButton_move1;
    pre_rotate_Button = ui->pushButton_rotate1;

}

void MainWindow::TimerOut()
{
    QString     stringdata;
    timer->stop();              //关闭定时器
    ui->RecvTextEdit->setTextColor(QColor(Qt::black));
    // 读取串口接收的数据
    QByteArray  RecvBuff = serialPort->readAll();
    if(ui->recvcheckBox->isChecked())
    {
        stringdata = RecvBuff.toHex(' ').trimmed().toUpper();/*hex显示*/
    }
    else
    {
       stringdata = QString(RecvBuff);   /*ascii显示*/
    }

    /*时间戳按钮*/
    if (ui->timecheckBox->isChecked())
    {
       stringdata = QString("[%1]:RX -> %2").arg(QTime::currentTime().toString("HH:mm:ss:zzz")).arg(stringdata);
       ui->RecvTextEdit->append(stringdata);
    }
    else
    {
        ui->RecvTextEdit->insertPlainText(stringdata);
    }
    ui->RecvTextEdit->moveCursor(QTextCursor::End);  // 自动滚屏到最后一行 有BUG 不可用光标点击文本框
    dataRxNumber += RecvBuff.length();
    ui->RxNumlabel->setText(QString::number(dataRxNumber));
    RecvBuff.clear();
}
void MainWindow::serialPortReadyRead_Slot()
{
    //启动定时器
    timer->start(10);
}

/*函   数：on_OpenUart_clicked
描   述：打开并设置串口的信号槽函数
输   入：无
输   出：无
*/
void MainWindow::on_OpenUart_clicked()
{

    serialPort->setPortName(ui->uartbox->currentText());
    serialPort->setBaudRate(ui->baudbox->currentText().toInt());            //设置波特率
    serialPort->setDataBits(QSerialPort::Data8);                            //设置数据位数  默认8位
    serialPort->setParity(QSerialPort::NoParity);                           //设置奇偶校验  默认无奇偶
    serialPort->setStopBits(QSerialPort::OneStop);                          //设置停止位    默认无停止
    serialPort->setFlowControl(QSerialPort::NoFlowControl);                 //设置流控制    默认无

    connect(serialPort,SIGNAL(readyRead()),this,SLOT(serialPortReadyRead_Slot()));

    if(serialPort->open(QIODevice::ReadWrite))              //打开串口成功
    {
        ui->OpenUart->setEnabled(false);
        ui->CloseUart->setEnabled(true);
        Serial_State = true;
        QMessageBox::warning(this,tr("提示"),tr("串口连接成功"));
    }
    else
    {
        QMessageBox::warning(this,tr("错误"),tr("串口连接失败"));
    }

}


void MainWindow::on_CloseUart_clicked()
{
    serialPort->close();
    Serial_State = 0;
    ui->OpenUart->setEnabled(true);     // 连接串口按键使能
    ui->CloseUart->setEnabled(false);   // 断开按键关使能
}
/*
    函   数：find_port
    描   述：查找串口
    输   入：无
    输   出：无
*/
void MainWindow::find_port()
{
    ui->uartbox->clear();
    foreach(const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
    {
        QSerialPort serial;
        serial.setPort(info);   //设置串口
        if(serial.open(QIODevice::ReadWrite))
        {
            ui->uartbox->addItem(serial.portName());        //显示串口名称
            serial.close();
        }
    }
}

void MainWindow::ClearRecvButton()
{
    ui->RecvTextEdit->clear();
    dataRxNumber = 0 ;
    ui->RxNumlabel->setText(QString::number(dataRxNumber));
}
/*
    函   数：SaveRecvDataFile
    描   述：保存数据按钮点击槽函数
    输   入：无
    输   出：无
*/
void MainWindow::SaveRecvDataFile()
{
    QString data;

    data = ui->RecvTextEdit->toPlainText();

    if (data.isEmpty())
    {
        QMessageBox::information(this, "提示", "数据内容空");
        return;
    }
    QString curPath = QDir::currentPath();            //获取系统当前目录
    QString dlgTitle = "保存文件";                     //对话框标题
    QString filter = "文本文件(*.txt);;所有文件(*.*)";  //文件过滤器
    QString filename = QFileDialog::getSaveFileName(this,dlgTitle,curPath,filter);
    if (filename.isEmpty())
    {
        return;
    }
    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly))
    {
        return;
    }
    /*保存文件*/
    QTextStream stream(&file);
    stream << data;
    file.close();
}

/*
    函   数：on_SendDataFile_clicked
    描   述：手动发送数据
    输   入：无
    输   出：无
*/
void MainWindow::on_SendDataFile_clicked()
{

    if (bool(Serial_State) == true)
    {
        //获取发送框字符
        SendTextStr = ui->SendTextEdit->document()->toPlainText();
        SendTextByte = SendTextStr.toUtf8();
        if (SendTextByte.isEmpty() != true)
        {

            if (ui->HexsendcheckBox->isChecked())
            {
                SendTextByte = SendTextByte.fromHex(SendTextByte);
                serialPort->write(SendTextByte); // 发送hex数据
                QString strdata = SendTextByte.toHex(' ').trimmed().toUpper();
                if (ui->timecheckBox->isChecked()) // 时间戳发送
                {
                    ui->RecvTextEdit->setTextColor(QColor(Qt::blue));  // 时间戳颜色
                    ui->RecvTextEdit->append(QString("[%1]TX -> ").arg(QTime::currentTime().toString("HH:mm:ss:zzz")));
                }
                else
                {
                  strdata = strdata.append("\r\n");
                }
                ui->RecvTextEdit->setTextColor(QColor(Qt::black));
                ui->RecvTextEdit->insertPlainText(strdata);
            }
            else
            {
                // 发送ascii数据
                serialPort->write(SendTextByte);
                QString strdata = QString(SendTextByte);
                if (ui->timecheckBox->isChecked()) // 时间戳发送
                {
                    ui->RecvTextEdit->setTextColor(QColor(Qt::red)); // 时间戳颜色
                    ui->RecvTextEdit->append(QString("[%1]TX -> ").arg(QTime::currentTime().toString("HH:mm:ss:zzz")));
                }
                else
                {
                   strdata = strdata.append("\r\n");
                }
                ui->RecvTextEdit->setTextColor(QColor(Qt::black));
                ui->RecvTextEdit->insertPlainText(strdata);
            }
            //移动光标到末尾
            ui->RecvTextEdit->moveCursor(QTextCursor::End);
        }
        else
        {
            QMessageBox::warning(this, "警告", "您需要在发送编辑框中输入要发送的数据");
        }

    }
    else
    {
        QMessageBox::information(this, "警告", "串口未打开");
    }
}
/*
    函   数：TimeSendReady
    描   述：定时发送信号槽函数
    输   入：无
    输   出：无
*/
void MainWindow::TimeSendReady(int state)
{
    int settime;

    if (bool(Serial_State) == false)
    {
        QMessageBox::information(this, "提示", "串口未打开");
        return;
    }
    /*判断是否有数据*/
    if (ui->SendTextEdit->document()->isEmpty() == true)
    {
        if (ui->timesendcheckBox->isChecked())
        {
            QMessageBox::warning(this, "警告", "您需要在发送编辑框中输入要发送的数据");
        }
        return;
    }
    /*判断勾选状态*/
    if (state == Qt::Checked)
    {
        /*获取设定时间*/
        settime = ui->timelineEdit->text().toInt();
        if (settime > 0) {
            timersend->start(settime);
        } else {
            QMessageBox::warning(this, "警告", "时间必须大于0");
        }
        ui->timelineEdit->setEnabled(false);
    }
    else
    {
        /*停止发送*/
        timersend->stop();
        ui->timelineEdit->setEnabled(true);
    }
}
void MainWindow::SendDataHex(int state)
{
    //获取发送框字符
    SendTextStr = ui->SendTextEdit->document()->toPlainText();
    SendTextByte = SendTextStr.toUtf8();
    if (SendTextStr.isEmpty())
    {
        return;
    }
    //asccii与hex转换
    if (state == Qt::Checked)
    {
        //转换成16进制数并转换为大写
        SendTextByte = SendTextByte.toHex(' ').toUpper();
        ui->SendTextEdit->document()->setPlainText(SendTextByte);
    }
    else
    {
        //从QByteArray转换为QString
        SendTextStr = SendTextByte.fromHex(SendTextByte);
        ui->SendTextEdit->document()->setPlainText(SendTextStr);
    }
}

void MainWindow::on_RefreshUart_clicked()
{
    ui->uartbox->clear();
    foreach(const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
    {
        QSerialPort serial;
        serial.setPort(info);   //设置串口
        if(serial.open(QIODevice::ReadWrite))
        {
            ui->uartbox->addItem(serial.portName());        //显示串口名称
            serial.close();
        }
    }
}

void MainWindow::on_pushButton_yaw_left_clicked()
{
    m_Angle_Yaw = m_Angle_Yaw - angleSize;
    ui->label_data_yaw->setText(QString::number(m_Angle_Yaw));
    if_position_changed();
}


void MainWindow::on_pushButton_yaw_right_clicked()
{
    m_Angle_Yaw = m_Angle_Yaw + angleSize;
    ui->label_data_yaw->setText(QString::number(m_Angle_Yaw));
    if_position_changed();
}


void MainWindow::on_pushButton_roll_left_clicked()
{
    m_Angle_Roll = m_Angle_Roll - angleSize;
    ui->label_data_roll->setText(QString::number(m_Angle_Roll));
    if_position_changed();
}


void MainWindow::on_pushButton_roll_right_clicked()
{
    m_Angle_Roll = m_Angle_Roll + angleSize;
    ui->label_data_roll->setText(QString::number(m_Angle_Roll));
    if_position_changed();
}


void MainWindow::on_pushButton_pitch_left_clicked()
{
    m_Angle_Pitch = m_Angle_Pitch - angleSize;
    ui->label_data_pitch->setText(QString::number(m_Angle_Pitch));
    if_position_changed();
}


void MainWindow::on_pushButton_pitch_right_clicked()
{
    m_Angle_Pitch = m_Angle_Pitch + angleSize;
    ui->label_data_pitch->setText(QString::number(m_Angle_Pitch));
    if_position_changed();
}


void MainWindow::on_pushButton_toward_clicked()
{
    m_Position_y = m_Position_y + moveSize;
    ui->label_data_y->setText(QString::number(m_Position_y));
    if_position_changed();
}


void MainWindow::on_pushButton_backward_clicked()
{
    m_Position_y = m_Position_y - moveSize;
    ui->label_data_y->setText(QString::number(m_Position_y));
    if_position_changed();
}


void MainWindow::on_pushButton_leftward_clicked()
{
    m_Position_x = m_Position_x - moveSize;
    ui->label_data_x->setText(QString::number(m_Position_x));
    if_position_changed();
}


void MainWindow::on_pushButton_rightward_clicked()
{
    m_Position_x = m_Position_x + moveSize;
    ui->label_data_x->setText(QString::number(m_Position_x));
    if_position_changed();
}


void MainWindow::on_pushButton_upward_clicked()
{
    m_Position_z = m_Position_z - moveSize;
    ui->label_data_z->setText(QString::number(m_Position_z));
    if_position_changed();
}


void MainWindow::on_pushButton_downward_clicked()
{
    m_Position_z = m_Position_z + moveSize;
    ui->label_data_z->setText(QString::number(m_Position_z));
    if_position_changed();
}


void MainWindow::on_pushButton_move1_clicked()
{
    moveSize = 1;
    if (pre_move_Button != ui->pushButton_move1){
        ui->pushButton_move1->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_move1;
    }
}


void MainWindow::on_pushButton_move10_clicked()
{
    moveSize = 10;
    if (pre_move_Button != ui->pushButton_move10){
        ui->pushButton_move10->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_move10;
    }
}


void MainWindow::on_pushButton_move25_clicked()
{
    moveSize = 25;
    if (pre_move_Button != ui->pushButton_move25){
        ui->pushButton_move25->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_move25;
    }
}


void MainWindow::on_pushButton_move50_clicked()
{
    moveSize = 50;
    if (pre_move_Button != ui->pushButton_move50){
        ui->pushButton_move50->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_move50;
    }
}


void MainWindow::on_pushButton_move100_clicked()
{
    moveSize = 100;
    if (pre_move_Button != ui->pushButton_move100){
        ui->pushButton_move100->setStyleSheet(string_button_pressed_style);
        pre_move_Button->setStyleSheet(string_button_unpressed_style);
        pre_move_Button = ui->pushButton_move100;
    }
}


void MainWindow::on_pushButton_rotate1_clicked()
{
    angleSize = 1;
    if (pre_rotate_Button != ui->pushButton_rotate1){
        ui->pushButton_rotate1->setStyleSheet(string_button_pressed_style);
        pre_rotate_Button->setStyleSheet(string_button_unpressed_style);
        pre_rotate_Button = ui->pushButton_rotate1;
    }
}


void MainWindow::on_pushButton_rotate5_clicked()
{
    angleSize = 5;
    if (pre_rotate_Button != ui->pushButton_rotate5){
        ui->pushButton_rotate5->setStyleSheet(string_button_pressed_style);
        pre_rotate_Button->setStyleSheet(string_button_unpressed_style);
        pre_rotate_Button = ui->pushButton_rotate5;
    }
}


void MainWindow::on_pushButton_rotate10_clicked()
{
    angleSize = 10;
    if (pre_rotate_Button != ui->pushButton_rotate10){
        ui->pushButton_rotate10->setStyleSheet(string_button_pressed_style);
        pre_rotate_Button->setStyleSheet(string_button_unpressed_style);
        pre_rotate_Button = ui->pushButton_rotate10;
    }
}

void MainWindow::CommandSender(QString commander_content, float value)
{
    if(commander_content == "GX" or commander_content == "GY" or commander_content == "GZ" or commander_content == "TP" or commander_content == "TY" or commander_content == "TR")
    {
        ui->SendTextEdit->append(QString("%1 %2").arg(commander_content).arg(QString::number(value,'f',4)));
    }
    else
    {
        ui->RecvTextEdit->setText("valid command");
    }
}

void MainWindow::CommandSender(QString whole_command)
{
    QStringList list1 = whole_command.split(' ');
    std::vector<std::map<QString, float> > per_command;
    std::map<QString, std::pair<std::vector<float*>, QLabel *> >  match_command_pdata;
    match_command_pdata["GX"].first = {& m_Position_x, & m_pre_Position_x};
    match_command_pdata["GY"].first = {& m_Position_y, & m_pre_Position_y};
    match_command_pdata["GZ"].first = {& m_Position_z, & m_pre_Position_z};
    match_command_pdata["TR"].first = {& m_Angle_Roll, & m_pre_Angle_Roll};
    match_command_pdata["TP"].first = {& m_Angle_Pitch, & m_pre_Angle_Pitch};
    match_command_pdata["TY"].first = {& m_Angle_Yaw, & m_pre_Angle_Yaw};
    match_command_pdata["GX"].second = ui->label_data_x;
    match_command_pdata["GY"].second = ui->label_data_y;
    match_command_pdata["GZ"].second = ui->label_data_z;
    match_command_pdata["TR"].second = ui->label_data_roll;
    match_command_pdata["TP"].second = ui->label_data_pitch;
    match_command_pdata["TY"].second = ui->label_data_yaw;
    if(whole_command.left(1) != 'G' and whole_command.left(1)!= 'T')
    {
        QMessageBox::warning(this, "警告", "命令错误");
    }
    else
    {
        for(auto iter = list1.begin();iter != list1.end(); ++iter)
        {
            //iter->left2对应GX，要找到GX对应m_Position_x的方法，然后改pre、m_position_x以及ui->x
            *(match_command_pdata[iter->left(2)].first[0]) = QString(iter->mid(2)).toFloat();
            *(match_command_pdata[iter->left(2)].first[1]) = QString(iter->mid(2)).toFloat();
            match_command_pdata[iter->left(2)].second->setText(QString::number(*(match_command_pdata[iter->left(2)].first[0])));
            //同时赋值pre即可解决问题
        }
        ui->SendTextEdit->append(whole_command);
    }

}
void MainWindow::if_position_changed()
{
    if ( m_pre_Position_x != m_Position_x)
    {
        m_pre_Position_x = m_Position_x;
        CommandSender("GX", m_Position_x);
    }
    else if (m_pre_Position_y != m_Position_y)
    {
        m_pre_Position_y = m_Position_y;
        CommandSender("GY", m_Position_y);
    }
    else if (m_pre_Position_z != m_Position_z)
    {
        m_pre_Position_z = m_Position_z;
        CommandSender("GZ", m_Position_z);
    }
    else if (m_pre_Angle_Pitch != m_Angle_Pitch)
    {
        m_pre_Angle_Pitch = m_Angle_Pitch;
        CommandSender("TP", m_Angle_Pitch);
    }
    else if (m_pre_Angle_Roll != m_Angle_Roll)
    {
        m_pre_Angle_Roll = m_Angle_Roll;
        CommandSender("TR", m_Angle_Roll);
    }
    else if (m_pre_Angle_Yaw != m_Angle_Yaw)
    {
        m_pre_Angle_Yaw = m_Angle_Yaw;
        CommandSender("TY", m_Angle_Yaw);
    }
}

void MainWindow::on_lineEdit_command_input_returnPressed()
{
    if (bool(Serial_State) == true)
    {
        //获取发送框字符
        SendTextStr = ui->lineEdit_command_input->text();

        //要将QString转变为char*才能实现发送字符串
        std::string String_TextStr = SendTextStr.toStdString();
        const char* StringSend = String_TextStr.c_str();
        SendTextByte = SendTextStr.toUtf8();
        //StringSend为真正要发的数据
        if (String_TextStr.empty() != true)
        {
            CommandSender(ui->lineEdit_command_input->text());

            // 发送ascii数据
            serialPort->write(StringSend);
            QString strdata = QString(SendTextByte);
            if (ui->timecheckBox->isChecked()) // 时间戳发送
            {
                ui->SendTextEdit->setTextColor(QColor(Qt::red)); // 时间戳颜色
                ui->SendTextEdit->append(QString("[%1]TX -> ").arg(QTime::currentTime().toString("HH:mm:ss:zzz")));
            }
            else
            {
               strdata = strdata.append("\r\n");
            }
            ui->lineEdit_command_input->setText("");
        }

        else
        {
            QMessageBox::warning(this, "警告", "您需要在发送编辑框中输入要发送的数据");
        }

    }
    else
    {
        QMessageBox::information(this, "警告", "串口未打开");
    }

}

