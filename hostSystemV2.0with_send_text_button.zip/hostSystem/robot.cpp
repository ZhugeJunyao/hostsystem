#include "robot.h"

Robot::Robot()
{
    m_real_x = 0, m_real_y = 0;

}

void Robot::CommandSender(char command)
{

    switch(command)
    {
        case 'I' : ;break;                             //确认是否初始化
        case 'G' : break;
        case ' ' : break;

    }
}

float Robot::GetPositionX()
{
    return m_real_x;
}

float Robot::GetPositionY()
{
    return m_real_y;
}

float Robot::GetPositionZ()
{
    return m_real_z;
}

std::vector<float> Robot::GetPosition()
{
    std::vector<float> vector3(3);
    vector3[0] = GetPositionX();
    vector3[1] = GetPositionY();
    vector3[2] = GetPositionZ();
    return vector3;
}
